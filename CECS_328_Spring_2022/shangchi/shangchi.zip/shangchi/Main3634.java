package shangchi;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main3634 {

	public static void main(String[] args) {
	
		//1
		boolean passed = Testing90210.test(6, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//2
		passed = Testing90210.test(7, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//3
		passed = Testing90210.test(9, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//4
		passed = Testing90210.test(25, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//5
		passed = Testing90210.test(50, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//6
		passed = Testing90210.test(100, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//7
		passed = Testing90210.test(500, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//8
		passed = Testing90210.test(1000, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//9
		passed = Testing90210.test(1500, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//10
		passed = Testing90210.test(1900, false);
		System.out.println(passed);
		System.out.println(Testing90210.message);
		
		//stackOverflow at 1930 sometimes
	}
	
	
}


